package com.capgemini.datasource;

import com.capgemini.bean.Account;



public class AccountDataSource {
	
	public boolean save(Account, amount){}
	
	public Account 

}
