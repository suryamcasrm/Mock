package com.capgemini.exception;

public class InsufAmountException extends Exception {

}
