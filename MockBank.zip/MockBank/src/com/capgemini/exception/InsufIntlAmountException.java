package com.capgemini.exception;

public class InsufIntlAmountException extends Exception {

}
